﻿namespace Take_Home_Apdev_Week_8
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.topWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tShirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.longPantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.otherToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dgv_cart = new System.Windows.Forms.DataGridView();
            this.lbl_totalsub = new System.Windows.Forms.Label();
            this.lbl_ttotal = new System.Windows.Forms.Label();
            this.lbl_tshirt1 = new System.Windows.Forms.Label();
            this.lbl_tshirt2 = new System.Windows.Forms.Label();
            this.lbl_tshirt3 = new System.Windows.Forms.Label();
            this.panel_tshirt = new System.Windows.Forms.Panel();
            this.pb_tshirt3 = new System.Windows.Forms.PictureBox();
            this.btn_addTshirt3 = new System.Windows.Forms.Button();
            this.pb_tshirt1 = new System.Windows.Forms.PictureBox();
            this.btn_addTshirt2 = new System.Windows.Forms.Button();
            this.pb_tshirt2 = new System.Windows.Forms.PictureBox();
            this.btn_addTshirt1 = new System.Windows.Forms.Button();
            this.lbl_ptshirt3 = new System.Windows.Forms.Label();
            this.lbl_ptshirt2 = new System.Windows.Forms.Label();
            this.lbl_ptshirt1 = new System.Windows.Forms.Label();
            this.panel_others = new System.Windows.Forms.Panel();
            this.pb_others = new System.Windows.Forms.PictureBox();
            this.tb_itemPrice = new System.Windows.Forms.TextBox();
            this.lbl_itemPrice = new System.Windows.Forms.Label();
            this.tb_itemName = new System.Windows.Forms.TextBox();
            this.lbl_itemName = new System.Windows.Forms.Label();
            this.lbl_uploadImage = new System.Windows.Forms.Label();
            this.btn_addCartOthers = new System.Windows.Forms.Button();
            this.btn_upload = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.panel_shirt = new System.Windows.Forms.Panel();
            this.pb_shirt3 = new System.Windows.Forms.PictureBox();
            this.btn_addShirt3 = new System.Windows.Forms.Button();
            this.pb_shirt1 = new System.Windows.Forms.PictureBox();
            this.btn_addShirt2 = new System.Windows.Forms.Button();
            this.pb_shirt2 = new System.Windows.Forms.PictureBox();
            this.btn_addShirt1 = new System.Windows.Forms.Button();
            this.lbl_shirt1 = new System.Windows.Forms.Label();
            this.lbl_pshirt3 = new System.Windows.Forms.Label();
            this.lbl_shirt2 = new System.Windows.Forms.Label();
            this.lbl_pshirt2 = new System.Windows.Forms.Label();
            this.lbl_shirt3 = new System.Windows.Forms.Label();
            this.lbl_pshirt1 = new System.Windows.Forms.Label();
            this.panel_pants = new System.Windows.Forms.Panel();
            this.pb_pants3 = new System.Windows.Forms.PictureBox();
            this.btn_addPants3 = new System.Windows.Forms.Button();
            this.pb_pants1 = new System.Windows.Forms.PictureBox();
            this.btn_addPants2 = new System.Windows.Forms.Button();
            this.pb_pants2 = new System.Windows.Forms.PictureBox();
            this.btn_addPants1 = new System.Windows.Forms.Button();
            this.lbl_pants1 = new System.Windows.Forms.Label();
            this.lbl_ppants3 = new System.Windows.Forms.Label();
            this.lbl_pants2 = new System.Windows.Forms.Label();
            this.lbl_ppants2 = new System.Windows.Forms.Label();
            this.lbl_pants3 = new System.Windows.Forms.Label();
            this.lbl_ppants1 = new System.Windows.Forms.Label();
            this.panel_longpants = new System.Windows.Forms.Panel();
            this.pb_longpants3 = new System.Windows.Forms.PictureBox();
            this.btn_longpants3 = new System.Windows.Forms.Button();
            this.pb_longpants1 = new System.Windows.Forms.PictureBox();
            this.btn_longpants2 = new System.Windows.Forms.Button();
            this.pb_longpants2 = new System.Windows.Forms.PictureBox();
            this.btn_longpants1 = new System.Windows.Forms.Button();
            this.lbl_longpants1 = new System.Windows.Forms.Label();
            this.lbl_plongpants3 = new System.Windows.Forms.Label();
            this.lbl_longpants2 = new System.Windows.Forms.Label();
            this.lbl_plongpants2 = new System.Windows.Forms.Label();
            this.lbl_longpants3 = new System.Windows.Forms.Label();
            this.lbl_plongpants1 = new System.Windows.Forms.Label();
            this.panel_shoes = new System.Windows.Forms.Panel();
            this.pb_shoes3 = new System.Windows.Forms.PictureBox();
            this.btn_shoes3 = new System.Windows.Forms.Button();
            this.pb_shoes1 = new System.Windows.Forms.PictureBox();
            this.btn_shoes2 = new System.Windows.Forms.Button();
            this.pb_shoes2 = new System.Windows.Forms.PictureBox();
            this.btn_shoes1 = new System.Windows.Forms.Button();
            this.lbl_shoes1 = new System.Windows.Forms.Label();
            this.lbl_pshoes3 = new System.Windows.Forms.Label();
            this.lbl_shoes2 = new System.Windows.Forms.Label();
            this.lbl_pshoes2 = new System.Windows.Forms.Label();
            this.lbl_shoes3 = new System.Windows.Forms.Label();
            this.lbl_pshoes1 = new System.Windows.Forms.Label();
            this.panel_jewels = new System.Windows.Forms.Panel();
            this.pb_jewels3 = new System.Windows.Forms.PictureBox();
            this.btn_jewels3 = new System.Windows.Forms.Button();
            this.pb_jewels1 = new System.Windows.Forms.PictureBox();
            this.btn_jewels2 = new System.Windows.Forms.Button();
            this.pb_jewels2 = new System.Windows.Forms.PictureBox();
            this.btn_jewels1 = new System.Windows.Forms.Button();
            this.lbl_jewels1 = new System.Windows.Forms.Label();
            this.lbl_pjewels3 = new System.Windows.Forms.Label();
            this.lbl_jewels2 = new System.Windows.Forms.Label();
            this.lbl_pjewels2 = new System.Windows.Forms.Label();
            this.lbl_jewels3 = new System.Windows.Forms.Label();
            this.lbl_pjewels1 = new System.Windows.Forms.Label();
            this.lbl_subTotal = new System.Windows.Forms.Label();
            this.lbl_total = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_cart)).BeginInit();
            this.panel_tshirt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tshirt3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tshirt1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tshirt2)).BeginInit();
            this.panel_others.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_others)).BeginInit();
            this.panel_shirt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_shirt3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_shirt1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_shirt2)).BeginInit();
            this.panel_pants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_pants3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_pants1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_pants2)).BeginInit();
            this.panel_longpants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_longpants3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_longpants1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_longpants2)).BeginInit();
            this.panel_shoes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_shoes3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_shoes1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_shoes2)).BeginInit();
            this.panel_jewels.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_jewels3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_jewels1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_jewels2)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topWearToolStripMenuItem,
            this.bottomWearToolStripMenuItem,
            this.accToolStripMenuItem,
            this.otherToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1184, 36);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // topWearToolStripMenuItem
            // 
            this.topWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tShirtToolStripMenuItem,
            this.shirtToolStripMenuItem});
            this.topWearToolStripMenuItem.Name = "topWearToolStripMenuItem";
            this.topWearToolStripMenuItem.Size = new System.Drawing.Size(102, 29);
            this.topWearToolStripMenuItem.Text = "Top Wear";
            // 
            // tShirtToolStripMenuItem
            // 
            this.tShirtToolStripMenuItem.Name = "tShirtToolStripMenuItem";
            this.tShirtToolStripMenuItem.Size = new System.Drawing.Size(166, 34);
            this.tShirtToolStripMenuItem.Text = "T-Shirt";
            this.tShirtToolStripMenuItem.Click += new System.EventHandler(this.tShirtToolStripMenuItem_Click);
            // 
            // shirtToolStripMenuItem
            // 
            this.shirtToolStripMenuItem.Name = "shirtToolStripMenuItem";
            this.shirtToolStripMenuItem.Size = new System.Drawing.Size(166, 34);
            this.shirtToolStripMenuItem.Text = "Shirt";
            this.shirtToolStripMenuItem.Click += new System.EventHandler(this.shirtToolStripMenuItem_Click);
            // 
            // bottomWearToolStripMenuItem
            // 
            this.bottomWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pantsToolStripMenuItem,
            this.longPantsToolStripMenuItem});
            this.bottomWearToolStripMenuItem.Name = "bottomWearToolStripMenuItem";
            this.bottomWearToolStripMenuItem.Size = new System.Drawing.Size(133, 29);
            this.bottomWearToolStripMenuItem.Text = "Bottom Wear";
            // 
            // pantsToolStripMenuItem
            // 
            this.pantsToolStripMenuItem.Name = "pantsToolStripMenuItem";
            this.pantsToolStripMenuItem.Size = new System.Drawing.Size(201, 34);
            this.pantsToolStripMenuItem.Text = "Pants";
            this.pantsToolStripMenuItem.Click += new System.EventHandler(this.pantsToolStripMenuItem_Click);
            // 
            // longPantsToolStripMenuItem
            // 
            this.longPantsToolStripMenuItem.Name = "longPantsToolStripMenuItem";
            this.longPantsToolStripMenuItem.Size = new System.Drawing.Size(201, 34);
            this.longPantsToolStripMenuItem.Text = "Long Pants";
            this.longPantsToolStripMenuItem.Click += new System.EventHandler(this.longPantsToolStripMenuItem_Click);
            // 
            // accToolStripMenuItem
            // 
            this.accToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shoesToolStripMenuItem,
            this.jewToolStripMenuItem});
            this.accToolStripMenuItem.Name = "accToolStripMenuItem";
            this.accToolStripMenuItem.Size = new System.Drawing.Size(119, 29);
            this.accToolStripMenuItem.Text = "Accessories";
            // 
            // shoesToolStripMenuItem
            // 
            this.shoesToolStripMenuItem.Name = "shoesToolStripMenuItem";
            this.shoesToolStripMenuItem.Size = new System.Drawing.Size(195, 34);
            this.shoesToolStripMenuItem.Text = "Shoes";
            this.shoesToolStripMenuItem.Click += new System.EventHandler(this.shoesToolStripMenuItem_Click);
            // 
            // jewToolStripMenuItem
            // 
            this.jewToolStripMenuItem.Name = "jewToolStripMenuItem";
            this.jewToolStripMenuItem.Size = new System.Drawing.Size(195, 34);
            this.jewToolStripMenuItem.Text = "Jewelleries";
            this.jewToolStripMenuItem.Click += new System.EventHandler(this.jewToolStripMenuItem_Click);
            // 
            // otherToolStripMenuItem
            // 
            this.otherToolStripMenuItem.Name = "otherToolStripMenuItem";
            this.otherToolStripMenuItem.Size = new System.Drawing.Size(73, 29);
            this.otherToolStripMenuItem.Text = "Other";
            this.otherToolStripMenuItem.Click += new System.EventHandler(this.otherToolStripMenuItem_Click);
            // 
            // dgv_cart
            // 
            this.dgv_cart.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_cart.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgv_cart.Location = new System.Drawing.Point(610, 76);
            this.dgv_cart.Name = "dgv_cart";
            this.dgv_cart.RowHeadersVisible = false;
            this.dgv_cart.RowHeadersWidth = 62;
            this.dgv_cart.RowTemplate.Height = 28;
            this.dgv_cart.Size = new System.Drawing.Size(562, 387);
            this.dgv_cart.TabIndex = 1;
            // 
            // lbl_totalsub
            // 
            this.lbl_totalsub.AutoSize = true;
            this.lbl_totalsub.Font = new System.Drawing.Font("Segoe UI Emoji", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_totalsub.Location = new System.Drawing.Point(604, 491);
            this.lbl_totalsub.Name = "lbl_totalsub";
            this.lbl_totalsub.Size = new System.Drawing.Size(141, 32);
            this.lbl_totalsub.TabIndex = 5;
            this.lbl_totalsub.Text = "Sub-Total :";
            // 
            // lbl_ttotal
            // 
            this.lbl_ttotal.AutoSize = true;
            this.lbl_ttotal.Font = new System.Drawing.Font("Segoe UI Emoji", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ttotal.Location = new System.Drawing.Point(659, 543);
            this.lbl_ttotal.Name = "lbl_ttotal";
            this.lbl_ttotal.Size = new System.Drawing.Size(86, 32);
            this.lbl_ttotal.TabIndex = 6;
            this.lbl_ttotal.Text = "Total :";
            // 
            // lbl_tshirt1
            // 
            this.lbl_tshirt1.AutoSize = true;
            this.lbl_tshirt1.Location = new System.Drawing.Point(3, 252);
            this.lbl_tshirt1.Name = "lbl_tshirt1";
            this.lbl_tshirt1.Size = new System.Drawing.Size(134, 20);
            this.lbl_tshirt1.TabIndex = 9;
            this.lbl_tshirt1.Text = "Kaos Hitam Polos";
            // 
            // lbl_tshirt2
            // 
            this.lbl_tshirt2.AutoSize = true;
            this.lbl_tshirt2.Location = new System.Drawing.Point(194, 252);
            this.lbl_tshirt2.Name = "lbl_tshirt2";
            this.lbl_tshirt2.Size = new System.Drawing.Size(168, 20);
            this.lbl_tshirt2.TabIndex = 10;
            this.lbl_tshirt2.Text = "Kaos Putih Bergambar";
            // 
            // lbl_tshirt3
            // 
            this.lbl_tshirt3.AutoSize = true;
            this.lbl_tshirt3.Location = new System.Drawing.Point(383, 252);
            this.lbl_tshirt3.Name = "lbl_tshirt3";
            this.lbl_tshirt3.Size = new System.Drawing.Size(145, 20);
            this.lbl_tshirt3.TabIndex = 11;
            this.lbl_tshirt3.Text = "Kaos Hitam Tulisan";
            // 
            // panel_tshirt
            // 
            this.panel_tshirt.Controls.Add(this.pb_tshirt3);
            this.panel_tshirt.Controls.Add(this.btn_addTshirt3);
            this.panel_tshirt.Controls.Add(this.pb_tshirt1);
            this.panel_tshirt.Controls.Add(this.btn_addTshirt2);
            this.panel_tshirt.Controls.Add(this.pb_tshirt2);
            this.panel_tshirt.Controls.Add(this.btn_addTshirt1);
            this.panel_tshirt.Controls.Add(this.lbl_tshirt1);
            this.panel_tshirt.Controls.Add(this.lbl_ptshirt3);
            this.panel_tshirt.Controls.Add(this.lbl_tshirt2);
            this.panel_tshirt.Controls.Add(this.lbl_ptshirt2);
            this.panel_tshirt.Controls.Add(this.lbl_tshirt3);
            this.panel_tshirt.Controls.Add(this.lbl_ptshirt1);
            this.panel_tshirt.Location = new System.Drawing.Point(12, 87);
            this.panel_tshirt.Name = "panel_tshirt";
            this.panel_tshirt.Size = new System.Drawing.Size(582, 355);
            this.panel_tshirt.TabIndex = 12;
            this.panel_tshirt.Visible = false;
            // 
            // pb_tshirt3
            // 
            this.pb_tshirt3.Image = global::Take_Home_Apdev_Week_8.Properties.Resources.t_shirt_3;
            this.pb_tshirt3.Location = new System.Drawing.Point(387, 17);
            this.pb_tshirt3.Name = "pb_tshirt3";
            this.pb_tshirt3.Size = new System.Drawing.Size(172, 207);
            this.pb_tshirt3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_tshirt3.TabIndex = 4;
            this.pb_tshirt3.TabStop = false;
            // 
            // btn_addTshirt3
            // 
            this.btn_addTshirt3.Location = new System.Drawing.Point(387, 305);
            this.btn_addTshirt3.Name = "btn_addTshirt3";
            this.btn_addTshirt3.Size = new System.Drawing.Size(111, 39);
            this.btn_addTshirt3.TabIndex = 18;
            this.btn_addTshirt3.Text = "Add to Cart";
            this.btn_addTshirt3.UseVisualStyleBackColor = true;
            this.btn_addTshirt3.Click += new System.EventHandler(this.btn_addTshirt3_Click);
            // 
            // pb_tshirt1
            // 
            this.pb_tshirt1.Image = global::Take_Home_Apdev_Week_8.Properties.Resources.t_shirt_1;
            this.pb_tshirt1.Location = new System.Drawing.Point(7, 17);
            this.pb_tshirt1.Name = "pb_tshirt1";
            this.pb_tshirt1.Size = new System.Drawing.Size(172, 207);
            this.pb_tshirt1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_tshirt1.TabIndex = 2;
            this.pb_tshirt1.TabStop = false;
            // 
            // btn_addTshirt2
            // 
            this.btn_addTshirt2.Location = new System.Drawing.Point(198, 305);
            this.btn_addTshirt2.Name = "btn_addTshirt2";
            this.btn_addTshirt2.Size = new System.Drawing.Size(111, 39);
            this.btn_addTshirt2.TabIndex = 17;
            this.btn_addTshirt2.Text = "Add to Cart";
            this.btn_addTshirt2.UseVisualStyleBackColor = true;
            this.btn_addTshirt2.Click += new System.EventHandler(this.btn_addTshirt2_Click);
            // 
            // pb_tshirt2
            // 
            this.pb_tshirt2.Image = global::Take_Home_Apdev_Week_8.Properties.Resources.t_shirt_2;
            this.pb_tshirt2.Location = new System.Drawing.Point(198, 17);
            this.pb_tshirt2.Name = "pb_tshirt2";
            this.pb_tshirt2.Size = new System.Drawing.Size(172, 207);
            this.pb_tshirt2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_tshirt2.TabIndex = 3;
            this.pb_tshirt2.TabStop = false;
            // 
            // btn_addTshirt1
            // 
            this.btn_addTshirt1.Location = new System.Drawing.Point(7, 305);
            this.btn_addTshirt1.Name = "btn_addTshirt1";
            this.btn_addTshirt1.Size = new System.Drawing.Size(111, 39);
            this.btn_addTshirt1.TabIndex = 16;
            this.btn_addTshirt1.Text = "Add to Cart";
            this.btn_addTshirt1.UseVisualStyleBackColor = true;
            this.btn_addTshirt1.Click += new System.EventHandler(this.btn_addTshirt1_Click);
            // 
            // lbl_ptshirt3
            // 
            this.lbl_ptshirt3.AutoSize = true;
            this.lbl_ptshirt3.Location = new System.Drawing.Point(383, 282);
            this.lbl_ptshirt3.Name = "lbl_ptshirt3";
            this.lbl_ptshirt3.Size = new System.Drawing.Size(87, 20);
            this.lbl_ptshirt3.TabIndex = 15;
            this.lbl_ptshirt3.Text = "Rp. 65.000";
            // 
            // lbl_ptshirt2
            // 
            this.lbl_ptshirt2.AutoSize = true;
            this.lbl_ptshirt2.Location = new System.Drawing.Point(194, 282);
            this.lbl_ptshirt2.Name = "lbl_ptshirt2";
            this.lbl_ptshirt2.Size = new System.Drawing.Size(87, 20);
            this.lbl_ptshirt2.TabIndex = 14;
            this.lbl_ptshirt2.Text = "Rp. 60.000";
            // 
            // lbl_ptshirt1
            // 
            this.lbl_ptshirt1.AutoSize = true;
            this.lbl_ptshirt1.Location = new System.Drawing.Point(3, 282);
            this.lbl_ptshirt1.Name = "lbl_ptshirt1";
            this.lbl_ptshirt1.Size = new System.Drawing.Size(91, 20);
            this.lbl_ptshirt1.TabIndex = 13;
            this.lbl_ptshirt1.Text = "Rp. 50.000.";
            // 
            // panel_others
            // 
            this.panel_others.Controls.Add(this.pb_others);
            this.panel_others.Controls.Add(this.tb_itemPrice);
            this.panel_others.Controls.Add(this.lbl_itemPrice);
            this.panel_others.Controls.Add(this.tb_itemName);
            this.panel_others.Controls.Add(this.lbl_itemName);
            this.panel_others.Controls.Add(this.lbl_uploadImage);
            this.panel_others.Controls.Add(this.btn_addCartOthers);
            this.panel_others.Controls.Add(this.btn_upload);
            this.panel_others.Location = new System.Drawing.Point(0, 90);
            this.panel_others.Name = "panel_others";
            this.panel_others.Size = new System.Drawing.Size(582, 355);
            this.panel_others.TabIndex = 20;
            this.panel_others.Visible = false;
            // 
            // pb_others
            // 
            this.pb_others.Location = new System.Drawing.Point(67, 61);
            this.pb_others.Name = "pb_others";
            this.pb_others.Size = new System.Drawing.Size(172, 207);
            this.pb_others.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_others.TabIndex = 19;
            this.pb_others.TabStop = false;
            // 
            // tb_itemPrice
            // 
            this.tb_itemPrice.Enabled = false;
            this.tb_itemPrice.Location = new System.Drawing.Point(261, 167);
            this.tb_itemPrice.Name = "tb_itemPrice";
            this.tb_itemPrice.Size = new System.Drawing.Size(179, 26);
            this.tb_itemPrice.TabIndex = 21;
            this.tb_itemPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_itemPrice_KeyPress);
            // 
            // lbl_itemPrice
            // 
            this.lbl_itemPrice.AutoSize = true;
            this.lbl_itemPrice.Location = new System.Drawing.Point(257, 144);
            this.lbl_itemPrice.Name = "lbl_itemPrice";
            this.lbl_itemPrice.Size = new System.Drawing.Size(84, 20);
            this.lbl_itemPrice.TabIndex = 24;
            this.lbl_itemPrice.Text = "Item Price:";
            // 
            // tb_itemName
            // 
            this.tb_itemName.Enabled = false;
            this.tb_itemName.Location = new System.Drawing.Point(261, 110);
            this.tb_itemName.Name = "tb_itemName";
            this.tb_itemName.Size = new System.Drawing.Size(179, 26);
            this.tb_itemName.TabIndex = 20;
            // 
            // lbl_itemName
            // 
            this.lbl_itemName.AutoSize = true;
            this.lbl_itemName.Location = new System.Drawing.Point(257, 87);
            this.lbl_itemName.Name = "lbl_itemName";
            this.lbl_itemName.Size = new System.Drawing.Size(91, 20);
            this.lbl_itemName.TabIndex = 23;
            this.lbl_itemName.Text = "Item Name:";
            // 
            // lbl_uploadImage
            // 
            this.lbl_uploadImage.AutoSize = true;
            this.lbl_uploadImage.Location = new System.Drawing.Point(119, 22);
            this.lbl_uploadImage.Name = "lbl_uploadImage";
            this.lbl_uploadImage.Size = new System.Drawing.Size(109, 20);
            this.lbl_uploadImage.TabIndex = 22;
            this.lbl_uploadImage.Text = "Upload Image";
            // 
            // btn_addCartOthers
            // 
            this.btn_addCartOthers.Enabled = false;
            this.btn_addCartOthers.Location = new System.Drawing.Point(261, 213);
            this.btn_addCartOthers.Name = "btn_addCartOthers";
            this.btn_addCartOthers.Size = new System.Drawing.Size(111, 39);
            this.btn_addCartOthers.TabIndex = 19;
            this.btn_addCartOthers.Text = "Add to Cart";
            this.btn_addCartOthers.UseVisualStyleBackColor = true;
            this.btn_addCartOthers.Click += new System.EventHandler(this.btn_addCartOthers_Click);
            // 
            // btn_upload
            // 
            this.btn_upload.Location = new System.Drawing.Point(261, 20);
            this.btn_upload.Name = "btn_upload";
            this.btn_upload.Size = new System.Drawing.Size(93, 32);
            this.btn_upload.TabIndex = 21;
            this.btn_upload.Text = "Upload";
            this.btn_upload.UseVisualStyleBackColor = true;
            this.btn_upload.Click += new System.EventHandler(this.btn_upload_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(763, 593);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(100, 40);
            this.btn_delete.TabIndex = 19;
            this.btn_delete.Text = "Delete Item";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // panel_shirt
            // 
            this.panel_shirt.Controls.Add(this.pb_shirt3);
            this.panel_shirt.Controls.Add(this.btn_addShirt3);
            this.panel_shirt.Controls.Add(this.pb_shirt1);
            this.panel_shirt.Controls.Add(this.btn_addShirt2);
            this.panel_shirt.Controls.Add(this.pb_shirt2);
            this.panel_shirt.Controls.Add(this.btn_addShirt1);
            this.panel_shirt.Controls.Add(this.lbl_shirt1);
            this.panel_shirt.Controls.Add(this.lbl_pshirt3);
            this.panel_shirt.Controls.Add(this.lbl_shirt2);
            this.panel_shirt.Controls.Add(this.lbl_pshirt2);
            this.panel_shirt.Controls.Add(this.lbl_shirt3);
            this.panel_shirt.Controls.Add(this.lbl_pshirt1);
            this.panel_shirt.Location = new System.Drawing.Point(12, 87);
            this.panel_shirt.Name = "panel_shirt";
            this.panel_shirt.Size = new System.Drawing.Size(582, 355);
            this.panel_shirt.TabIndex = 19;
            this.panel_shirt.Visible = false;
            // 
            // pb_shirt3
            // 
            this.pb_shirt3.Image = global::Take_Home_Apdev_Week_8.Properties.Resources.shirt_3;
            this.pb_shirt3.Location = new System.Drawing.Point(387, 17);
            this.pb_shirt3.Name = "pb_shirt3";
            this.pb_shirt3.Size = new System.Drawing.Size(172, 207);
            this.pb_shirt3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_shirt3.TabIndex = 4;
            this.pb_shirt3.TabStop = false;
            // 
            // btn_addShirt3
            // 
            this.btn_addShirt3.Location = new System.Drawing.Point(387, 305);
            this.btn_addShirt3.Name = "btn_addShirt3";
            this.btn_addShirt3.Size = new System.Drawing.Size(111, 39);
            this.btn_addShirt3.TabIndex = 18;
            this.btn_addShirt3.Text = "Add to Cart";
            this.btn_addShirt3.UseVisualStyleBackColor = true;
            this.btn_addShirt3.Click += new System.EventHandler(this.btn_addShirt3_Click);
            // 
            // pb_shirt1
            // 
            this.pb_shirt1.Image = global::Take_Home_Apdev_Week_8.Properties.Resources.shirt_1;
            this.pb_shirt1.Location = new System.Drawing.Point(7, 17);
            this.pb_shirt1.Name = "pb_shirt1";
            this.pb_shirt1.Size = new System.Drawing.Size(172, 207);
            this.pb_shirt1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_shirt1.TabIndex = 2;
            this.pb_shirt1.TabStop = false;
            // 
            // btn_addShirt2
            // 
            this.btn_addShirt2.Location = new System.Drawing.Point(198, 305);
            this.btn_addShirt2.Name = "btn_addShirt2";
            this.btn_addShirt2.Size = new System.Drawing.Size(111, 39);
            this.btn_addShirt2.TabIndex = 17;
            this.btn_addShirt2.Text = "Add to Cart";
            this.btn_addShirt2.UseVisualStyleBackColor = true;
            this.btn_addShirt2.Click += new System.EventHandler(this.btn_addShirt2_Click);
            // 
            // pb_shirt2
            // 
            this.pb_shirt2.Image = global::Take_Home_Apdev_Week_8.Properties.Resources.shirt_2;
            this.pb_shirt2.Location = new System.Drawing.Point(198, 17);
            this.pb_shirt2.Name = "pb_shirt2";
            this.pb_shirt2.Size = new System.Drawing.Size(172, 207);
            this.pb_shirt2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_shirt2.TabIndex = 3;
            this.pb_shirt2.TabStop = false;
            // 
            // btn_addShirt1
            // 
            this.btn_addShirt1.Location = new System.Drawing.Point(7, 305);
            this.btn_addShirt1.Name = "btn_addShirt1";
            this.btn_addShirt1.Size = new System.Drawing.Size(111, 39);
            this.btn_addShirt1.TabIndex = 16;
            this.btn_addShirt1.Text = "Add to Cart";
            this.btn_addShirt1.UseVisualStyleBackColor = true;
            this.btn_addShirt1.Click += new System.EventHandler(this.btn_addShirt1_Click);
            // 
            // lbl_shirt1
            // 
            this.lbl_shirt1.AutoSize = true;
            this.lbl_shirt1.Location = new System.Drawing.Point(3, 252);
            this.lbl_shirt1.Name = "lbl_shirt1";
            this.lbl_shirt1.Size = new System.Drawing.Size(109, 20);
            this.lbl_shirt1.TabIndex = 9;
            this.lbl_shirt1.Text = "Kemeja Flanel";
            // 
            // lbl_pshirt3
            // 
            this.lbl_pshirt3.AutoSize = true;
            this.lbl_pshirt3.Location = new System.Drawing.Point(383, 282);
            this.lbl_pshirt3.Name = "lbl_pshirt3";
            this.lbl_pshirt3.Size = new System.Drawing.Size(96, 20);
            this.lbl_pshirt3.TabIndex = 15;
            this.lbl_pshirt3.Text = "Rp. 120.000";
            // 
            // lbl_shirt2
            // 
            this.lbl_shirt2.AutoSize = true;
            this.lbl_shirt2.Location = new System.Drawing.Point(194, 252);
            this.lbl_shirt2.Name = "lbl_shirt2";
            this.lbl_shirt2.Size = new System.Drawing.Size(94, 20);
            this.lbl_shirt2.TabIndex = 10;
            this.lbl_shirt2.Text = "Kemeja Biru";
            // 
            // lbl_pshirt2
            // 
            this.lbl_pshirt2.AutoSize = true;
            this.lbl_pshirt2.Location = new System.Drawing.Point(194, 282);
            this.lbl_pshirt2.Name = "lbl_pshirt2";
            this.lbl_pshirt2.Size = new System.Drawing.Size(96, 20);
            this.lbl_pshirt2.TabIndex = 14;
            this.lbl_pshirt2.Text = "Rp. 110.000";
            // 
            // lbl_shirt3
            // 
            this.lbl_shirt3.AutoSize = true;
            this.lbl_shirt3.Location = new System.Drawing.Point(383, 252);
            this.lbl_shirt3.Name = "lbl_shirt3";
            this.lbl_shirt3.Size = new System.Drawing.Size(109, 20);
            this.lbl_shirt3.TabIndex = 11;
            this.lbl_shirt3.Text = "Kemeja Jeans";
            // 
            // lbl_pshirt1
            // 
            this.lbl_pshirt1.AutoSize = true;
            this.lbl_pshirt1.Location = new System.Drawing.Point(3, 282);
            this.lbl_pshirt1.Name = "lbl_pshirt1";
            this.lbl_pshirt1.Size = new System.Drawing.Size(100, 20);
            this.lbl_pshirt1.TabIndex = 13;
            this.lbl_pshirt1.Text = "Rp. 100.000.";
            // 
            // panel_pants
            // 
            this.panel_pants.Controls.Add(this.pb_pants3);
            this.panel_pants.Controls.Add(this.btn_addPants3);
            this.panel_pants.Controls.Add(this.pb_pants1);
            this.panel_pants.Controls.Add(this.btn_addPants2);
            this.panel_pants.Controls.Add(this.pb_pants2);
            this.panel_pants.Controls.Add(this.btn_addPants1);
            this.panel_pants.Controls.Add(this.lbl_pants1);
            this.panel_pants.Controls.Add(this.lbl_ppants3);
            this.panel_pants.Controls.Add(this.lbl_pants2);
            this.panel_pants.Controls.Add(this.lbl_ppants2);
            this.panel_pants.Controls.Add(this.lbl_pants3);
            this.panel_pants.Controls.Add(this.lbl_ppants1);
            this.panel_pants.Location = new System.Drawing.Point(12, 87);
            this.panel_pants.Name = "panel_pants";
            this.panel_pants.Size = new System.Drawing.Size(582, 355);
            this.panel_pants.TabIndex = 20;
            this.panel_pants.Visible = false;
            // 
            // pb_pants3
            // 
            this.pb_pants3.Image = global::Take_Home_Apdev_Week_8.Properties.Resources.short_pants_3;
            this.pb_pants3.Location = new System.Drawing.Point(387, 17);
            this.pb_pants3.Name = "pb_pants3";
            this.pb_pants3.Size = new System.Drawing.Size(172, 207);
            this.pb_pants3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_pants3.TabIndex = 4;
            this.pb_pants3.TabStop = false;
            // 
            // btn_addPants3
            // 
            this.btn_addPants3.Location = new System.Drawing.Point(387, 305);
            this.btn_addPants3.Name = "btn_addPants3";
            this.btn_addPants3.Size = new System.Drawing.Size(111, 39);
            this.btn_addPants3.TabIndex = 18;
            this.btn_addPants3.Text = "Add to Cart";
            this.btn_addPants3.UseVisualStyleBackColor = true;
            this.btn_addPants3.Click += new System.EventHandler(this.btn_addPants3_Click);
            // 
            // pb_pants1
            // 
            this.pb_pants1.Image = global::Take_Home_Apdev_Week_8.Properties.Resources.short_pants_1;
            this.pb_pants1.Location = new System.Drawing.Point(7, 17);
            this.pb_pants1.Name = "pb_pants1";
            this.pb_pants1.Size = new System.Drawing.Size(172, 207);
            this.pb_pants1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_pants1.TabIndex = 2;
            this.pb_pants1.TabStop = false;
            // 
            // btn_addPants2
            // 
            this.btn_addPants2.Location = new System.Drawing.Point(198, 305);
            this.btn_addPants2.Name = "btn_addPants2";
            this.btn_addPants2.Size = new System.Drawing.Size(111, 39);
            this.btn_addPants2.TabIndex = 17;
            this.btn_addPants2.Text = "Add to Cart";
            this.btn_addPants2.UseVisualStyleBackColor = true;
            this.btn_addPants2.Click += new System.EventHandler(this.btn_addPants2_Click);
            // 
            // pb_pants2
            // 
            this.pb_pants2.Image = global::Take_Home_Apdev_Week_8.Properties.Resources.short_pants_2;
            this.pb_pants2.Location = new System.Drawing.Point(198, 17);
            this.pb_pants2.Name = "pb_pants2";
            this.pb_pants2.Size = new System.Drawing.Size(172, 207);
            this.pb_pants2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_pants2.TabIndex = 3;
            this.pb_pants2.TabStop = false;
            // 
            // btn_addPants1
            // 
            this.btn_addPants1.Location = new System.Drawing.Point(7, 305);
            this.btn_addPants1.Name = "btn_addPants1";
            this.btn_addPants1.Size = new System.Drawing.Size(111, 39);
            this.btn_addPants1.TabIndex = 16;
            this.btn_addPants1.Text = "Add to Cart";
            this.btn_addPants1.UseVisualStyleBackColor = true;
            this.btn_addPants1.Click += new System.EventHandler(this.btn_addPants1_Click);
            // 
            // lbl_pants1
            // 
            this.lbl_pants1.AutoSize = true;
            this.lbl_pants1.Location = new System.Drawing.Point(3, 252);
            this.lbl_pants1.Name = "lbl_pants1";
            this.lbl_pants1.Size = new System.Drawing.Size(108, 20);
            this.lbl_pants1.TabIndex = 9;
            this.lbl_pants1.Text = "Celana Coklat";
            // 
            // lbl_ppants3
            // 
            this.lbl_ppants3.AutoSize = true;
            this.lbl_ppants3.Location = new System.Drawing.Point(383, 282);
            this.lbl_ppants3.Name = "lbl_ppants3";
            this.lbl_ppants3.Size = new System.Drawing.Size(87, 20);
            this.lbl_ppants3.TabIndex = 15;
            this.lbl_ppants3.Text = "Rp. 55.000";
            // 
            // lbl_pants2
            // 
            this.lbl_pants2.AutoSize = true;
            this.lbl_pants2.Location = new System.Drawing.Point(194, 252);
            this.lbl_pants2.Name = "lbl_pants2";
            this.lbl_pants2.Size = new System.Drawing.Size(174, 20);
            this.lbl_pants2.TabIndex = 10;
            this.lbl_pants2.Text = "Celana Olahraga Hitam";
            // 
            // lbl_ppants2
            // 
            this.lbl_ppants2.AutoSize = true;
            this.lbl_ppants2.Location = new System.Drawing.Point(194, 282);
            this.lbl_ppants2.Name = "lbl_ppants2";
            this.lbl_ppants2.Size = new System.Drawing.Size(87, 20);
            this.lbl_ppants2.TabIndex = 14;
            this.lbl_ppants2.Text = "Rp. 50.000";
            // 
            // lbl_pants3
            // 
            this.lbl_pants3.AutoSize = true;
            this.lbl_pants3.Location = new System.Drawing.Point(383, 252);
            this.lbl_pants3.Name = "lbl_pants3";
            this.lbl_pants3.Size = new System.Drawing.Size(152, 20);
            this.lbl_pants3.TabIndex = 11;
            this.lbl_pants3.Text = "Celana Coklat Muda";
            // 
            // lbl_ppants1
            // 
            this.lbl_ppants1.AutoSize = true;
            this.lbl_ppants1.Location = new System.Drawing.Point(3, 282);
            this.lbl_ppants1.Name = "lbl_ppants1";
            this.lbl_ppants1.Size = new System.Drawing.Size(87, 20);
            this.lbl_ppants1.TabIndex = 13;
            this.lbl_ppants1.Text = "Rp. 40.000";
            // 
            // panel_longpants
            // 
            this.panel_longpants.Controls.Add(this.pb_longpants3);
            this.panel_longpants.Controls.Add(this.btn_longpants3);
            this.panel_longpants.Controls.Add(this.pb_longpants1);
            this.panel_longpants.Controls.Add(this.btn_longpants2);
            this.panel_longpants.Controls.Add(this.pb_longpants2);
            this.panel_longpants.Controls.Add(this.btn_longpants1);
            this.panel_longpants.Controls.Add(this.lbl_longpants1);
            this.panel_longpants.Controls.Add(this.lbl_plongpants3);
            this.panel_longpants.Controls.Add(this.lbl_longpants2);
            this.panel_longpants.Controls.Add(this.lbl_plongpants2);
            this.panel_longpants.Controls.Add(this.lbl_longpants3);
            this.panel_longpants.Controls.Add(this.lbl_plongpants1);
            this.panel_longpants.Location = new System.Drawing.Point(12, 87);
            this.panel_longpants.Name = "panel_longpants";
            this.panel_longpants.Size = new System.Drawing.Size(582, 355);
            this.panel_longpants.TabIndex = 21;
            this.panel_longpants.Visible = false;
            // 
            // pb_longpants3
            // 
            this.pb_longpants3.Image = global::Take_Home_Apdev_Week_8.Properties.Resources.long_pants_3;
            this.pb_longpants3.Location = new System.Drawing.Point(387, 17);
            this.pb_longpants3.Name = "pb_longpants3";
            this.pb_longpants3.Size = new System.Drawing.Size(172, 207);
            this.pb_longpants3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_longpants3.TabIndex = 4;
            this.pb_longpants3.TabStop = false;
            // 
            // btn_longpants3
            // 
            this.btn_longpants3.Location = new System.Drawing.Point(387, 305);
            this.btn_longpants3.Name = "btn_longpants3";
            this.btn_longpants3.Size = new System.Drawing.Size(111, 39);
            this.btn_longpants3.TabIndex = 18;
            this.btn_longpants3.Text = "Add to Cart";
            this.btn_longpants3.UseVisualStyleBackColor = true;
            this.btn_longpants3.Click += new System.EventHandler(this.btn_longpants3_Click);
            // 
            // pb_longpants1
            // 
            this.pb_longpants1.Image = global::Take_Home_Apdev_Week_8.Properties.Resources.long_pants_1;
            this.pb_longpants1.Location = new System.Drawing.Point(7, 17);
            this.pb_longpants1.Name = "pb_longpants1";
            this.pb_longpants1.Size = new System.Drawing.Size(172, 207);
            this.pb_longpants1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_longpants1.TabIndex = 2;
            this.pb_longpants1.TabStop = false;
            // 
            // btn_longpants2
            // 
            this.btn_longpants2.Location = new System.Drawing.Point(198, 305);
            this.btn_longpants2.Name = "btn_longpants2";
            this.btn_longpants2.Size = new System.Drawing.Size(111, 39);
            this.btn_longpants2.TabIndex = 17;
            this.btn_longpants2.Text = "Add to Cart";
            this.btn_longpants2.UseVisualStyleBackColor = true;
            this.btn_longpants2.Click += new System.EventHandler(this.btn_longpants2_Click);
            // 
            // pb_longpants2
            // 
            this.pb_longpants2.Image = global::Take_Home_Apdev_Week_8.Properties.Resources.long_pants_2;
            this.pb_longpants2.Location = new System.Drawing.Point(198, 17);
            this.pb_longpants2.Name = "pb_longpants2";
            this.pb_longpants2.Size = new System.Drawing.Size(172, 207);
            this.pb_longpants2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_longpants2.TabIndex = 3;
            this.pb_longpants2.TabStop = false;
            // 
            // btn_longpants1
            // 
            this.btn_longpants1.Location = new System.Drawing.Point(7, 305);
            this.btn_longpants1.Name = "btn_longpants1";
            this.btn_longpants1.Size = new System.Drawing.Size(111, 39);
            this.btn_longpants1.TabIndex = 16;
            this.btn_longpants1.Text = "Add to Cart";
            this.btn_longpants1.UseVisualStyleBackColor = true;
            this.btn_longpants1.Click += new System.EventHandler(this.btn_longpants1_Click);
            // 
            // lbl_longpants1
            // 
            this.lbl_longpants1.AutoSize = true;
            this.lbl_longpants1.Location = new System.Drawing.Point(3, 252);
            this.lbl_longpants1.Name = "lbl_longpants1";
            this.lbl_longpants1.Size = new System.Drawing.Size(153, 20);
            this.lbl_longpants1.TabIndex = 9;
            this.lbl_longpants1.Text = "Celana Panjang Biru";
            // 
            // lbl_plongpants3
            // 
            this.lbl_plongpants3.AutoSize = true;
            this.lbl_plongpants3.Location = new System.Drawing.Point(383, 282);
            this.lbl_plongpants3.Name = "lbl_plongpants3";
            this.lbl_plongpants3.Size = new System.Drawing.Size(87, 20);
            this.lbl_plongpants3.TabIndex = 15;
            this.lbl_plongpants3.Text = "Rp. 80.000";
            // 
            // lbl_longpants2
            // 
            this.lbl_longpants2.AutoSize = true;
            this.lbl_longpants2.Location = new System.Drawing.Point(194, 252);
            this.lbl_longpants2.Name = "lbl_longpants2";
            this.lbl_longpants2.Size = new System.Drawing.Size(170, 20);
            this.lbl_longpants2.TabIndex = 10;
            this.lbl_longpants2.Text = "Celana Panjang Coklat";
            // 
            // lbl_plongpants2
            // 
            this.lbl_plongpants2.AutoSize = true;
            this.lbl_plongpants2.Location = new System.Drawing.Point(194, 282);
            this.lbl_plongpants2.Name = "lbl_plongpants2";
            this.lbl_plongpants2.Size = new System.Drawing.Size(87, 20);
            this.lbl_plongpants2.TabIndex = 14;
            this.lbl_plongpants2.Text = "Rp. 75.000";
            // 
            // lbl_longpants3
            // 
            this.lbl_longpants3.AutoSize = true;
            this.lbl_longpants3.Location = new System.Drawing.Point(383, 252);
            this.lbl_longpants3.Name = "lbl_longpants3";
            this.lbl_longpants3.Size = new System.Drawing.Size(167, 20);
            this.lbl_longpants3.TabIndex = 11;
            this.lbl_longpants3.Text = "Celana Panjang Hitam";
            // 
            // lbl_plongpants1
            // 
            this.lbl_plongpants1.AutoSize = true;
            this.lbl_plongpants1.Location = new System.Drawing.Point(3, 282);
            this.lbl_plongpants1.Name = "lbl_plongpants1";
            this.lbl_plongpants1.Size = new System.Drawing.Size(87, 20);
            this.lbl_plongpants1.TabIndex = 13;
            this.lbl_plongpants1.Text = "Rp. 70.000";
            // 
            // panel_shoes
            // 
            this.panel_shoes.Controls.Add(this.pb_shoes3);
            this.panel_shoes.Controls.Add(this.btn_shoes3);
            this.panel_shoes.Controls.Add(this.pb_shoes1);
            this.panel_shoes.Controls.Add(this.btn_shoes2);
            this.panel_shoes.Controls.Add(this.pb_shoes2);
            this.panel_shoes.Controls.Add(this.btn_shoes1);
            this.panel_shoes.Controls.Add(this.lbl_shoes1);
            this.panel_shoes.Controls.Add(this.lbl_pshoes3);
            this.panel_shoes.Controls.Add(this.lbl_shoes2);
            this.panel_shoes.Controls.Add(this.lbl_pshoes2);
            this.panel_shoes.Controls.Add(this.lbl_shoes3);
            this.panel_shoes.Controls.Add(this.lbl_pshoes1);
            this.panel_shoes.Location = new System.Drawing.Point(12, 87);
            this.panel_shoes.Name = "panel_shoes";
            this.panel_shoes.Size = new System.Drawing.Size(582, 355);
            this.panel_shoes.TabIndex = 22;
            this.panel_shoes.Visible = false;
            // 
            // pb_shoes3
            // 
            this.pb_shoes3.Image = global::Take_Home_Apdev_Week_8.Properties.Resources.shoes_3;
            this.pb_shoes3.Location = new System.Drawing.Point(387, 17);
            this.pb_shoes3.Name = "pb_shoes3";
            this.pb_shoes3.Size = new System.Drawing.Size(172, 207);
            this.pb_shoes3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_shoes3.TabIndex = 4;
            this.pb_shoes3.TabStop = false;
            // 
            // btn_shoes3
            // 
            this.btn_shoes3.Location = new System.Drawing.Point(387, 305);
            this.btn_shoes3.Name = "btn_shoes3";
            this.btn_shoes3.Size = new System.Drawing.Size(111, 39);
            this.btn_shoes3.TabIndex = 18;
            this.btn_shoes3.Text = "Add to Cart";
            this.btn_shoes3.UseVisualStyleBackColor = true;
            this.btn_shoes3.Click += new System.EventHandler(this.btn_shoes3_Click);
            // 
            // pb_shoes1
            // 
            this.pb_shoes1.Image = global::Take_Home_Apdev_Week_8.Properties.Resources.shoes_1;
            this.pb_shoes1.Location = new System.Drawing.Point(7, 17);
            this.pb_shoes1.Name = "pb_shoes1";
            this.pb_shoes1.Size = new System.Drawing.Size(172, 207);
            this.pb_shoes1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_shoes1.TabIndex = 2;
            this.pb_shoes1.TabStop = false;
            // 
            // btn_shoes2
            // 
            this.btn_shoes2.Location = new System.Drawing.Point(198, 305);
            this.btn_shoes2.Name = "btn_shoes2";
            this.btn_shoes2.Size = new System.Drawing.Size(111, 39);
            this.btn_shoes2.TabIndex = 17;
            this.btn_shoes2.Text = "Add to Cart";
            this.btn_shoes2.UseVisualStyleBackColor = true;
            this.btn_shoes2.Click += new System.EventHandler(this.btn_shoes2_Click);
            // 
            // pb_shoes2
            // 
            this.pb_shoes2.Image = global::Take_Home_Apdev_Week_8.Properties.Resources.shoes_2;
            this.pb_shoes2.Location = new System.Drawing.Point(198, 17);
            this.pb_shoes2.Name = "pb_shoes2";
            this.pb_shoes2.Size = new System.Drawing.Size(172, 207);
            this.pb_shoes2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_shoes2.TabIndex = 3;
            this.pb_shoes2.TabStop = false;
            // 
            // btn_shoes1
            // 
            this.btn_shoes1.Location = new System.Drawing.Point(7, 305);
            this.btn_shoes1.Name = "btn_shoes1";
            this.btn_shoes1.Size = new System.Drawing.Size(111, 39);
            this.btn_shoes1.TabIndex = 16;
            this.btn_shoes1.Text = "Add to Cart";
            this.btn_shoes1.UseVisualStyleBackColor = true;
            this.btn_shoes1.Click += new System.EventHandler(this.btn_shoes1_Click);
            // 
            // lbl_shoes1
            // 
            this.lbl_shoes1.AutoSize = true;
            this.lbl_shoes1.Location = new System.Drawing.Point(3, 252);
            this.lbl_shoes1.Name = "lbl_shoes1";
            this.lbl_shoes1.Size = new System.Drawing.Size(96, 20);
            this.lbl_shoes1.TabIndex = 9;
            this.lbl_shoes1.Text = "Sepatu Nike";
            // 
            // lbl_pshoes3
            // 
            this.lbl_pshoes3.AutoSize = true;
            this.lbl_pshoes3.Location = new System.Drawing.Point(383, 282);
            this.lbl_pshoes3.Name = "lbl_pshoes3";
            this.lbl_pshoes3.Size = new System.Drawing.Size(96, 20);
            this.lbl_pshoes3.TabIndex = 15;
            this.lbl_pshoes3.Text = "Rp. 250.000";
            // 
            // lbl_shoes2
            // 
            this.lbl_shoes2.AutoSize = true;
            this.lbl_shoes2.Location = new System.Drawing.Point(194, 252);
            this.lbl_shoes2.Name = "lbl_shoes2";
            this.lbl_shoes2.Size = new System.Drawing.Size(124, 20);
            this.lbl_shoes2.TabIndex = 10;
            this.lbl_shoes2.Text = "Sepatu Pantofel";
            // 
            // lbl_pshoes2
            // 
            this.lbl_pshoes2.AutoSize = true;
            this.lbl_pshoes2.Location = new System.Drawing.Point(194, 282);
            this.lbl_pshoes2.Name = "lbl_pshoes2";
            this.lbl_pshoes2.Size = new System.Drawing.Size(96, 20);
            this.lbl_pshoes2.TabIndex = 14;
            this.lbl_pshoes2.Text = "Rp. 300.000";
            // 
            // lbl_shoes3
            // 
            this.lbl_shoes3.AutoSize = true;
            this.lbl_shoes3.Location = new System.Drawing.Point(383, 252);
            this.lbl_shoes3.Name = "lbl_shoes3";
            this.lbl_shoes3.Size = new System.Drawing.Size(132, 20);
            this.lbl_shoes3.TabIndex = 11;
            this.lbl_shoes3.Text = "Sepatu Converse";
            // 
            // lbl_pshoes1
            // 
            this.lbl_pshoes1.AutoSize = true;
            this.lbl_pshoes1.Location = new System.Drawing.Point(3, 282);
            this.lbl_pshoes1.Name = "lbl_pshoes1";
            this.lbl_pshoes1.Size = new System.Drawing.Size(96, 20);
            this.lbl_pshoes1.TabIndex = 13;
            this.lbl_pshoes1.Text = "Rp. 200.000";
            // 
            // panel_jewels
            // 
            this.panel_jewels.Controls.Add(this.pb_jewels3);
            this.panel_jewels.Controls.Add(this.btn_jewels3);
            this.panel_jewels.Controls.Add(this.pb_jewels1);
            this.panel_jewels.Controls.Add(this.btn_jewels2);
            this.panel_jewels.Controls.Add(this.pb_jewels2);
            this.panel_jewels.Controls.Add(this.btn_jewels1);
            this.panel_jewels.Controls.Add(this.lbl_jewels1);
            this.panel_jewels.Controls.Add(this.lbl_pjewels3);
            this.panel_jewels.Controls.Add(this.lbl_jewels2);
            this.panel_jewels.Controls.Add(this.lbl_pjewels2);
            this.panel_jewels.Controls.Add(this.lbl_jewels3);
            this.panel_jewels.Controls.Add(this.lbl_pjewels1);
            this.panel_jewels.Location = new System.Drawing.Point(12, 87);
            this.panel_jewels.Name = "panel_jewels";
            this.panel_jewels.Size = new System.Drawing.Size(582, 355);
            this.panel_jewels.TabIndex = 23;
            this.panel_jewels.Visible = false;
            // 
            // pb_jewels3
            // 
            this.pb_jewels3.Image = global::Take_Home_Apdev_Week_8.Properties.Resources.gelang;
            this.pb_jewels3.Location = new System.Drawing.Point(387, 17);
            this.pb_jewels3.Name = "pb_jewels3";
            this.pb_jewels3.Size = new System.Drawing.Size(172, 207);
            this.pb_jewels3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_jewels3.TabIndex = 4;
            this.pb_jewels3.TabStop = false;
            // 
            // btn_jewels3
            // 
            this.btn_jewels3.Location = new System.Drawing.Point(387, 305);
            this.btn_jewels3.Name = "btn_jewels3";
            this.btn_jewels3.Size = new System.Drawing.Size(111, 39);
            this.btn_jewels3.TabIndex = 18;
            this.btn_jewels3.Text = "Add to Cart";
            this.btn_jewels3.UseVisualStyleBackColor = true;
            this.btn_jewels3.Click += new System.EventHandler(this.btn_jewels3_Click);
            // 
            // pb_jewels1
            // 
            this.pb_jewels1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pb_jewels1.Image = global::Take_Home_Apdev_Week_8.Properties.Resources.cincin;
            this.pb_jewels1.Location = new System.Drawing.Point(7, 17);
            this.pb_jewels1.Name = "pb_jewels1";
            this.pb_jewels1.Size = new System.Drawing.Size(172, 207);
            this.pb_jewels1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_jewels1.TabIndex = 2;
            this.pb_jewels1.TabStop = false;
            // 
            // btn_jewels2
            // 
            this.btn_jewels2.Location = new System.Drawing.Point(198, 305);
            this.btn_jewels2.Name = "btn_jewels2";
            this.btn_jewels2.Size = new System.Drawing.Size(111, 39);
            this.btn_jewels2.TabIndex = 17;
            this.btn_jewels2.Text = "Add to Cart";
            this.btn_jewels2.UseVisualStyleBackColor = true;
            this.btn_jewels2.Click += new System.EventHandler(this.btn_jewels2_Click);
            // 
            // pb_jewels2
            // 
            this.pb_jewels2.Image = global::Take_Home_Apdev_Week_8.Properties.Resources.kalung;
            this.pb_jewels2.Location = new System.Drawing.Point(198, 17);
            this.pb_jewels2.Name = "pb_jewels2";
            this.pb_jewels2.Size = new System.Drawing.Size(172, 207);
            this.pb_jewels2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_jewels2.TabIndex = 3;
            this.pb_jewels2.TabStop = false;
            // 
            // btn_jewels1
            // 
            this.btn_jewels1.Location = new System.Drawing.Point(7, 305);
            this.btn_jewels1.Name = "btn_jewels1";
            this.btn_jewels1.Size = new System.Drawing.Size(111, 39);
            this.btn_jewels1.TabIndex = 16;
            this.btn_jewels1.Text = "Add to Cart";
            this.btn_jewels1.UseVisualStyleBackColor = true;
            this.btn_jewels1.Click += new System.EventHandler(this.btn_jewels1_Click);
            // 
            // lbl_jewels1
            // 
            this.lbl_jewels1.AutoSize = true;
            this.lbl_jewels1.Location = new System.Drawing.Point(3, 252);
            this.lbl_jewels1.Name = "lbl_jewels1";
            this.lbl_jewels1.Size = new System.Drawing.Size(52, 20);
            this.lbl_jewels1.TabIndex = 9;
            this.lbl_jewels1.Text = "Cincin";
            // 
            // lbl_pjewels3
            // 
            this.lbl_pjewels3.AutoSize = true;
            this.lbl_pjewels3.Location = new System.Drawing.Point(383, 282);
            this.lbl_pjewels3.Name = "lbl_pjewels3";
            this.lbl_pjewels3.Size = new System.Drawing.Size(87, 20);
            this.lbl_pjewels3.TabIndex = 15;
            this.lbl_pjewels3.Text = "Rp. 80.000";
            // 
            // lbl_jewels2
            // 
            this.lbl_jewels2.AutoSize = true;
            this.lbl_jewels2.Location = new System.Drawing.Point(194, 252);
            this.lbl_jewels2.Name = "lbl_jewels2";
            this.lbl_jewels2.Size = new System.Drawing.Size(58, 20);
            this.lbl_jewels2.TabIndex = 10;
            this.lbl_jewels2.Text = "Kalung";
            // 
            // lbl_pjewels2
            // 
            this.lbl_pjewels2.AutoSize = true;
            this.lbl_pjewels2.Location = new System.Drawing.Point(194, 282);
            this.lbl_pjewels2.Name = "lbl_pjewels2";
            this.lbl_pjewels2.Size = new System.Drawing.Size(96, 20);
            this.lbl_pjewels2.TabIndex = 14;
            this.lbl_pjewels2.Text = "Rp. 100.000";
            // 
            // lbl_jewels3
            // 
            this.lbl_jewels3.AutoSize = true;
            this.lbl_jewels3.Location = new System.Drawing.Point(383, 252);
            this.lbl_jewels3.Name = "lbl_jewels3";
            this.lbl_jewels3.Size = new System.Drawing.Size(61, 20);
            this.lbl_jewels3.TabIndex = 11;
            this.lbl_jewels3.Text = "Gelang";
            // 
            // lbl_pjewels1
            // 
            this.lbl_pjewels1.AutoSize = true;
            this.lbl_pjewels1.Location = new System.Drawing.Point(3, 282);
            this.lbl_pjewels1.Name = "lbl_pjewels1";
            this.lbl_pjewels1.Size = new System.Drawing.Size(96, 20);
            this.lbl_pjewels1.TabIndex = 13;
            this.lbl_pjewels1.Text = "Rp. 120.000";
            // 
            // lbl_subTotal
            // 
            this.lbl_subTotal.AutoSize = true;
            this.lbl_subTotal.Location = new System.Drawing.Point(773, 501);
            this.lbl_subTotal.Name = "lbl_subTotal";
            this.lbl_subTotal.Size = new System.Drawing.Size(51, 20);
            this.lbl_subTotal.TabIndex = 24;
            this.lbl_subTotal.Text = "label1";
            // 
            // lbl_total
            // 
            this.lbl_total.AutoSize = true;
            this.lbl_total.Location = new System.Drawing.Point(773, 553);
            this.lbl_total.Name = "lbl_total";
            this.lbl_total.Size = new System.Drawing.Size(51, 20);
            this.lbl_total.TabIndex = 25;
            this.lbl_total.Text = "label2";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 684);
            this.Controls.Add(this.lbl_total);
            this.Controls.Add(this.lbl_subTotal);
            this.Controls.Add(this.panel_others);
            this.Controls.Add(this.panel_pants);
            this.Controls.Add(this.panel_shirt);
            this.Controls.Add(this.panel_shoes);
            this.Controls.Add(this.panel_tshirt);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.lbl_ttotal);
            this.Controls.Add(this.lbl_totalsub);
            this.Controls.Add(this.dgv_cart);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.panel_longpants);
            this.Controls.Add(this.panel_jewels);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_cart)).EndInit();
            this.panel_tshirt.ResumeLayout(false);
            this.panel_tshirt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tshirt3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tshirt1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tshirt2)).EndInit();
            this.panel_others.ResumeLayout(false);
            this.panel_others.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_others)).EndInit();
            this.panel_shirt.ResumeLayout(false);
            this.panel_shirt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_shirt3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_shirt1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_shirt2)).EndInit();
            this.panel_pants.ResumeLayout(false);
            this.panel_pants.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_pants3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_pants1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_pants2)).EndInit();
            this.panel_longpants.ResumeLayout(false);
            this.panel_longpants.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_longpants3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_longpants1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_longpants2)).EndInit();
            this.panel_shoes.ResumeLayout(false);
            this.panel_shoes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_shoes3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_shoes1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_shoes2)).EndInit();
            this.panel_jewels.ResumeLayout(false);
            this.panel_jewels.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_jewels3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_jewels1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_jewels2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem topWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem otherToolStripMenuItem;
        private System.Windows.Forms.DataGridView dgv_cart;
        private System.Windows.Forms.PictureBox pb_tshirt1;
        private System.Windows.Forms.PictureBox pb_tshirt2;
        private System.Windows.Forms.PictureBox pb_tshirt3;
        private System.Windows.Forms.Label lbl_totalsub;
        private System.Windows.Forms.Label lbl_ttotal;
        private System.Windows.Forms.Label lbl_tshirt1;
        private System.Windows.Forms.ToolStripMenuItem tShirtToolStripMenuItem;
        private System.Windows.Forms.Label lbl_tshirt2;
        private System.Windows.Forms.Label lbl_tshirt3;
        private System.Windows.Forms.ToolStripMenuItem shirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem longPantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jewToolStripMenuItem;
        private System.Windows.Forms.Panel panel_tshirt;
        private System.Windows.Forms.Label lbl_ptshirt1;
        private System.Windows.Forms.Label lbl_ptshirt2;
        private System.Windows.Forms.Label lbl_ptshirt3;
        private System.Windows.Forms.Button btn_addTshirt1;
        private System.Windows.Forms.Button btn_addTshirt2;
        private System.Windows.Forms.Button btn_addTshirt3;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Panel panel_others;
        private System.Windows.Forms.Button btn_addCartOthers;
        private System.Windows.Forms.Button btn_upload;
        private System.Windows.Forms.Label lbl_itemPrice;
        private System.Windows.Forms.Label lbl_itemName;
        private System.Windows.Forms.Label lbl_uploadImage;
        private System.Windows.Forms.TextBox tb_itemPrice;
        private System.Windows.Forms.TextBox tb_itemName;
        private System.Windows.Forms.Panel panel_shirt;
        private System.Windows.Forms.PictureBox pb_shirt3;
        private System.Windows.Forms.Button btn_addShirt3;
        private System.Windows.Forms.PictureBox pb_shirt1;
        private System.Windows.Forms.Button btn_addShirt2;
        private System.Windows.Forms.PictureBox pb_shirt2;
        private System.Windows.Forms.Button btn_addShirt1;
        private System.Windows.Forms.Label lbl_shirt1;
        private System.Windows.Forms.Label lbl_pshirt3;
        private System.Windows.Forms.Label lbl_shirt2;
        private System.Windows.Forms.Label lbl_pshirt2;
        private System.Windows.Forms.Label lbl_shirt3;
        private System.Windows.Forms.Label lbl_pshirt1;
        private System.Windows.Forms.Panel panel_pants;
        private System.Windows.Forms.PictureBox pb_pants3;
        private System.Windows.Forms.Button btn_addPants3;
        private System.Windows.Forms.PictureBox pb_pants1;
        private System.Windows.Forms.Button btn_addPants2;
        private System.Windows.Forms.PictureBox pb_pants2;
        private System.Windows.Forms.Button btn_addPants1;
        private System.Windows.Forms.Label lbl_pants1;
        private System.Windows.Forms.Label lbl_ppants3;
        private System.Windows.Forms.Label lbl_pants2;
        private System.Windows.Forms.Label lbl_ppants2;
        private System.Windows.Forms.Label lbl_pants3;
        private System.Windows.Forms.Label lbl_ppants1;
        private System.Windows.Forms.Panel panel_longpants;
        private System.Windows.Forms.PictureBox pb_longpants3;
        private System.Windows.Forms.Button btn_longpants3;
        private System.Windows.Forms.PictureBox pb_longpants1;
        private System.Windows.Forms.Button btn_longpants2;
        private System.Windows.Forms.PictureBox pb_longpants2;
        private System.Windows.Forms.Button btn_longpants1;
        private System.Windows.Forms.Label lbl_longpants1;
        private System.Windows.Forms.Label lbl_plongpants3;
        private System.Windows.Forms.Label lbl_longpants2;
        private System.Windows.Forms.Label lbl_plongpants2;
        private System.Windows.Forms.Label lbl_longpants3;
        private System.Windows.Forms.Label lbl_plongpants1;
        private System.Windows.Forms.Panel panel_shoes;
        private System.Windows.Forms.PictureBox pb_shoes3;
        private System.Windows.Forms.Button btn_shoes3;
        private System.Windows.Forms.PictureBox pb_shoes1;
        private System.Windows.Forms.Button btn_shoes2;
        private System.Windows.Forms.PictureBox pb_shoes2;
        private System.Windows.Forms.Button btn_shoes1;
        private System.Windows.Forms.Label lbl_shoes1;
        private System.Windows.Forms.Label lbl_pshoes3;
        private System.Windows.Forms.Label lbl_shoes2;
        private System.Windows.Forms.Label lbl_pshoes2;
        private System.Windows.Forms.Label lbl_shoes3;
        private System.Windows.Forms.Label lbl_pshoes1;
        private System.Windows.Forms.Panel panel_jewels;
        private System.Windows.Forms.PictureBox pb_jewels3;
        private System.Windows.Forms.Button btn_jewels3;
        private System.Windows.Forms.PictureBox pb_jewels1;
        private System.Windows.Forms.Button btn_jewels2;
        private System.Windows.Forms.PictureBox pb_jewels2;
        private System.Windows.Forms.Button btn_jewels1;
        private System.Windows.Forms.Label lbl_jewels1;
        private System.Windows.Forms.Label lbl_pjewels3;
        private System.Windows.Forms.Label lbl_jewels2;
        private System.Windows.Forms.Label lbl_pjewels2;
        private System.Windows.Forms.Label lbl_jewels3;
        private System.Windows.Forms.Label lbl_pjewels1;
        private System.Windows.Forms.PictureBox pb_others;
        private System.Windows.Forms.Label lbl_subTotal;
        private System.Windows.Forms.Label lbl_total;
    }
}

