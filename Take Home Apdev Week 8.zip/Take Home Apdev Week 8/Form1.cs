﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Take_Home_Apdev_Week_8
{
    public partial class Form1 : Form
    {
        DataTable cart = new DataTable();
        public Form1()
        {
            InitializeComponent();
            cart.Columns.Add("Nama Produk");
            cart.Columns.Add("Harga Produk");
            cart.Columns.Add("Kuantitas", typeof(int));
            cart.Columns.Add("Total", typeof(int));
            dgv_cart.DataSource = cart;
            dgv_cart.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgv_cart.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void visiblePanel()
        {
            panel_tshirt.Visible = false;
            panel_shirt.Visible = false;
            panel_pants.Visible = false;
            panel_longpants.Visible = false;
            panel_shoes.Visible = false;
            panel_jewels.Visible = false;
            panel_others.Visible = false;
        }
        private void tShirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            visiblePanel();
            panel_tshirt.Visible = true;
        }

        private void shirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            visiblePanel();
            panel_shirt.Visible = true;
        }

        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            visiblePanel();
            panel_pants.Visible = true;
        }

        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            visiblePanel();
            panel_longpants.Visible = true;
        }

        private void shoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            visiblePanel();
            panel_shoes.Visible = true;
        }

        private void jewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            visiblePanel();
            panel_jewels.Visible = true;
        }

        private void otherToolStripMenuItem_Click(object sender, EventArgs e)
        {
            visiblePanel();
            panel_others.Visible = true;
        }

        private void btn_addPants1_Click(object sender, EventArgs e)
        {
            string harga = lbl_ppants1.Text.Replace("Rp.", "");
            tambahItem(lbl_pants1.Text, Convert.ToDouble(harga));
            hitung();
        }

        private void btn_addPants2_Click(object sender, EventArgs e)
        {
            string harga = lbl_ppants2.Text.Replace("Rp.", "");
            tambahItem(lbl_pants2.Text, Convert.ToDouble(harga));
            hitung();
        }

        private void btn_addPants3_Click(object sender, EventArgs e)
        {
            string harga = lbl_ppants3.Text.Replace("Rp.", "");
            tambahItem(lbl_pants3.Text, Convert.ToDouble(harga));
            hitung();
        }
        private void btn_longpants1_Click(object sender, EventArgs e)
        {
            string harga = lbl_plongpants1.Text.Replace("Rp.", "");
            tambahItem(lbl_longpants1.Text, Convert.ToDouble(harga));
            hitung();
        }

        private void btn_longpants2_Click(object sender, EventArgs e)
        {
            string harga = lbl_plongpants2.Text.Replace("Rp.", "");
            tambahItem(lbl_longpants2.Text, Convert.ToDouble(harga));
            hitung();
        }

        private void btn_longpants3_Click(object sender, EventArgs e)
        {
            string harga = lbl_plongpants3.Text.Replace("Rp.", "");
            tambahItem(lbl_longpants3.Text, Convert.ToDouble(harga));
            hitung();
        }

        private void btn_jewels1_Click(object sender, EventArgs e)
        {
            string harga = lbl_pjewels1.Text.Replace("Rp.", "");
            tambahItem(lbl_jewels1.Text, Convert.ToDouble(harga));
            hitung();
        }

        private void btn_jewels2_Click(object sender, EventArgs e)
        {
            string harga = lbl_pjewels2.Text.Replace("Rp.", "");
            tambahItem(lbl_jewels2.Text, Convert.ToDouble(harga));
            hitung();
        }

        private void btn_jewels3_Click(object sender, EventArgs e)
        {
            string harga = lbl_pjewels3.Text.Replace("Rp.", "");
            tambahItem(lbl_jewels3.Text, Convert.ToDouble(harga));
            hitung();
        }

        private void btn_shoes1_Click(object sender, EventArgs e)
        {
            string harga = lbl_pshoes1.Text.Replace("Rp.", "");
            tambahItem(lbl_shoes1.Text, Convert.ToDouble(harga));
            hitung();
        }

        private void btn_shoes2_Click(object sender, EventArgs e)
        {
            string harga = lbl_pshoes2.Text.Replace("Rp.", "");
            tambahItem(lbl_shoes2.Text, Convert.ToDouble(harga));
            hitung();
        }

        private void btn_shoes3_Click(object sender, EventArgs e)
        {
            string harga = lbl_pshoes3.Text.Replace("Rp.", "");
            tambahItem(lbl_shoes3.Text, Convert.ToDouble(harga));
            hitung();
        }

        private void btn_addShirt1_Click(object sender, EventArgs e)
        {
            string harga = lbl_pshirt1.Text.Replace("Rp.", "");
            tambahItem(lbl_shirt1.Text, Convert.ToDouble(harga));
            hitung();
        }

        private void btn_addShirt2_Click(object sender, EventArgs e)
        {
            string harga = lbl_pshirt2.Text.Replace("Rp.", "");
            tambahItem(lbl_shirt2.Text, Convert.ToDouble(harga));
            hitung();
        }

        private void btn_addShirt3_Click(object sender, EventArgs e)
        {
            string harga = lbl_pshirt3.Text.Replace("Rp.", "");
            tambahItem(lbl_shirt3.Text, Convert.ToDouble(harga));
            hitung();
        }

        private void btn_addTshirt1_Click(object sender, EventArgs e)
        {
            string harga = lbl_ptshirt1.Text.Replace("Rp.", "");
            tambahItem(lbl_tshirt1.Text, Convert.ToDouble(harga));
            hitung();
        }

        private void btn_addTshirt2_Click(object sender, EventArgs e)
        {
            string harga = lbl_ptshirt2.Text.Replace("Rp.", "");
            tambahItem(lbl_tshirt2.Text, Convert.ToDouble(harga));
            hitung();
        }
        private void btn_addTshirt3_Click(object sender, EventArgs e)
        {
            string harga = lbl_ptshirt3.Text.Replace("Rp.", "");
            tambahItem(lbl_tshirt3.Text, Convert.ToDouble(harga));
            hitung();
        }

        private void btn_upload_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Image Files|*.png;*.jpg;*.jpeg|All Files|*.*";
                openFileDialog.FilterIndex = 1;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        pb_others.Image = Image.FromFile(openFileDialog.FileName);
                        tb_itemName.Enabled = true;
                        tb_itemPrice.Enabled = true;
                        btn_addCartOthers.Enabled = true;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Could not load the image: " + ex.Message);
                    }
                }
            }
        }

        private void btn_addCartOthers_Click(object sender, EventArgs e)
        {
            string namaproduk = tb_itemName.Text;
            double hargaproduk = Convert.ToDouble(tb_itemPrice.Text);

            bool produkSudahAda = false;
            foreach (DataRow row in cart.Rows)
            {
                if (row["Nama Produk"].ToString() == namaproduk)
                {
                    double hargaDiKeranjang = Convert.ToDouble(row["Harga Produk"]);
                    if (hargaDiKeranjang == hargaproduk)
                    {
                        int kuantitas = Convert.ToInt32(row["Kuantitas"]) + 1;
                        row["Kuantitas"] = kuantitas;
                        row["Total"] = kuantitas * hargaproduk;
                        produkSudahAda = true;
                        break;
                    }
                }
            }
            if (!produkSudahAda)
            {
                int kuantitas = 1;
                double total = kuantitas * hargaproduk;
                cart.Rows.Add(namaproduk, hargaproduk, kuantitas, total);
            }
            hitung();
            tb_itemName.Clear();
            tb_itemPrice.Clear();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (dgv_cart.SelectedRows.Count > 0)
            {
                foreach(DataGridViewRow row in dgv_cart.SelectedRows)
                {
                    cart.Rows.RemoveAt(row.Index);
                }
            }
            else
            {
                MessageBox.Show("Pilih produk yang ingin dihapus");
            }
            dgv_cart.ClearSelection();
            hitung();
        }

        private void hitung()
        {
            double harga = 0;
            foreach (DataRow row in cart.Rows)
            {
                double tempHarga;
                if (double.TryParse(row["Total"].ToString(), out tempHarga))
                {
                    harga += tempHarga;
                }
            }
            lbl_subTotal.Text = harga.ToString();
            double aftertax = harga + harga * 0.1;
            lbl_total.Text = aftertax.ToString("C", CultureInfo.CreateSpecificCulture("id-ID"));
        }

        private void tambahItem(string namaProduk, double hargaProduk)
        {
            int kuantitas = 1;
            bool quantity = false;

            foreach (DataRow row in cart.Rows)
            {
                if (row["Nama Produk"].ToString() == namaProduk)
                {
                    row["Kuantitas"] = Convert.ToInt32(row["Kuantitas"]) + 1;
                    row["Total"] = Convert.ToInt32(row["Kuantitas"]) * hargaProduk;
                    quantity = true;
                    break;
                }
            }
            if (!quantity)
            {
                double total = kuantitas * hargaProduk;
                cart.Rows.Add(namaProduk, hargaProduk, kuantitas, total);
            }
            hitung();
        }

        private void tb_itemPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
